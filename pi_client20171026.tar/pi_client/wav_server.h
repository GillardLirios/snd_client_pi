#ifndef __WAV_SERVER_H__
#define __WAV_SERVER_H__
int wav_server_start(int port);
void wav_server_stop(void);
#endif

