#!/bin/sh
cd /home/pi/tinyalsa/pi_client
sudo ./pi_main 127.0.0.1 1201 1201

