#include "state_client.h"
#include <stdio.h>
#include <stdlib.h>
#include<unistd.h>
#include <pthread.h>
#include "rpi_gpio.h"
#include <event.h>

void state_thread(void *ptr);
STATE_CLIENT_CALLBACK  cb_fun;
int state_client_start(STATE_CLIENT_CALLBACK cb,const char* ip, int port)
{
	printf("%s %s:%d\r\n",__FUNCTION__,ip, port);
	cb_fun = cb;
	cb(1, 0);
	pthread_t fd_thread;
	pthread_attr_t attr;
	pthread_attr_init (&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	char *message1 = "thread state client";
	int ret_thrd;
	ret_thrd = pthread_create(&fd_thread, &attr, (void *)&state_thread, (void *) message1);
	pthread_attr_destroy (&attr);
	if (ret_thrd != 0) {
         printf("线程%s创建失败\n",message1);
     } else {
         printf("线程%s创建成功\n",message1);
	}
	return 0;
}
void state_client_stop(void)
{
}


void state_thread(void *ptr)
{
	printf("%s, %s start\n", __FUNCTION__, (char*)ptr);
	//gpio_export(6);
	//gpio_export(13);
	//gpio_export(19);
	gpio_direction(6,IN);	//door sensor
	gpio_direction(13,OUT);	//pa pwr en
	gpio_direction(19,OUT);	//3110 en
	int gpio13 = 0;
	int call = 0;
	
	while(1)
	{
		call = gpio_read(6);
		printf("gpio6=%d\r\n", gpio_read(6));
		gpio_write(13,gpio13);
		gpio13 = !gpio13;
		sleep(3);
	}
//	gpio_unexport(6);
//	gpio_unexport(13);
//	gpio_unexport(19);
}


