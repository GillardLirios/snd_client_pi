#ifndef __WAV_CLIENT_H__
#define __WAV_CLIENT_H__


int wav_client_start(const char* ip, int port);
void wav_client_stop(void);
#endif

