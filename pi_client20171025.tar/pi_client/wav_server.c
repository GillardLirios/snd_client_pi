#include "wav_server.h"
#include <stdio.h>
int wav_server_start(int port)
{
	printf("%s %d\r\n",__FUNCTION__, port);
	return 0;
}

void wav_server_stop(void)
{
}
