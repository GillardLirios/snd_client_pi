#include "wav_client.h"
#include <stdio.h>
int wav_client_start(const char* ip, int port)
{
	printf("%s %s:%d\r\n",__FUNCTION__,ip, port);
	return 0;
}

void wav_client_stop(void)
{
}
