#include <stdio.h>
#include "state_client.h"
#include "wav_client.h"
#include "wav_server.h"
#include <stdlib.h>

#include<unistd.h>
int state_client_callback(int cmd, int para)
{
	printf("%s cmd=%d, para=%d\r\n",__FUNCTION__, cmd, para);
	switch(cmd)
	{
	case 1:
		wav_client_start("192.168.1.201", 8001);
		wav_server_start(8002);
	}
	
	return 0;
}

int  main(int argc, char* argv[])
{
	if(argc!=2)
	{
		printf("pi_main rip\r\n");
		return -1;
	}
 
	printf("remote:%s\r\n", argv[1]);
	
	state_client_start(state_client_callback, "192.168.1.201",7000);
	while(1){
		sleep(1);	
	}
	return 0;
}
